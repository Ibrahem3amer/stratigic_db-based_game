
//global variable to hold the data 
__data = {};

window.addEventListener("load",  function(){
	
	getData();
	
	displayMyTechnologies();
	
	displayResearchNewTechnology();
});


function getData(){
	
	var dataStr = document.getElementById("dataDiv").innerText;
	
	__data = JSON.parse(dataStr);
	
}


function displayMyTechnologies(){
	
	var myTechnologies = __data.myTechnologies;
	
	var table = getTbody(document.getElementById("table_myTechnologies"));
	

	for (var tech in myTechnologies) {
		if (myTechnologies.hasOwnProperty(tech)) {
			
			var newTr = document.createElement("TR"),
				newTdName = document.createElement("TD"),
				newTdDesc = document.createElement("TD");
				
				
			newTdName.innerText = tech;
			newTdDesc.innerText = myTechnologies[tech];
			
			newTr.appendChild(newTdName);
			newTr.appendChild(newTdDesc);
			
			table.appendChild(newTr);
			
		}
		
	}
	
}


function displayResearchNewTechnology(){

	//you could also get techInfo using AJAX
	var techInfo = __data.technologyInfo;
	
	
	
	//p_techDesc
	var p_techDesc = document.getElementById("p_techDesc");
	p_techDesc.innerText = techInfo.description;
	
	
	//tr_researchCost
	var tr_researchCost = document.getElementById("tr_researchCost");
	//tr_researchCost.innerHTML = "";
	
	
	var resources = techInfo.researchResourcesCost;
	var n = 0;
	var newTr = document.createElement("TR");
	var prevNode = tr_researchCost;
	for (var resource in resources) {
		if (resources.hasOwnProperty(resource)) {
			
			if(n == 2){
				n = 0;
				insertAfter(newTr,prevNode);
				prevNode = newTr;
				newTr = document.createElement("TR");
				
			}
			
			var newTdName = document.createElement("TD"),
				newTdVal = document.createElement("TD");
				
			newTdName.innerText = resource;
			newTdName.width = "25%";
			
			var ownRes = __data["nationResources"][resource] || "0",
				reqRes = resources[resource],
				clr = (parseInt(ownRes, 10) < parseInt(reqRes, 10))? "red" : "green",
				warn = (clr == "red")? SYMB_WARN : "";
			
			newTdVal.innerHTML = "<span class = '"+ clr+"'>" + ownRes + "/ <b>"  + reqRes + " </b>" + warn+"</span>" ;
			newTdVal.width = "25%";
			
			newTr.appendChild(newTdName);
			newTr.appendChild(newTdVal);
			n++;
			
			
		}
	}
	if(n == 1){
		
		//there is a remaining row with only one item in it, so
		//add an empty item after it 
		var newTdName = document.createElement("TD"),
				newTdVal = document.createElement("TD");
				
			newTdName.innerText = "";
			newTdName.width = "25%";
			
			newTdVal.innerText = "";
			newTdVal.width = "25%";
			
			newTr.appendChild(newTdName);
			newTr.appendChild(newTdVal);
			
			
		//then append it 
		insertAfter(newTr, prevNode);
	}
	
	
	
	//tr_requiredBuildings
	var tr_requiredBuildings = document.getElementById("tr_requiredBuildings");
	//tr_requiredBuildings.innerHTML = "";
	
	
	var buildings = techInfo.requiredBuildings;
	var n = 0;
	var newTr = document.createElement("TR");
	var prevNode = tr_requiredBuildings;
	for (var item in buildings) {
		if (buildings.hasOwnProperty(item)) {
			
			if(n == 2){
				n = 0;
				insertAfter(newTr,prevNode);
				prevNode = newTr;
				newTr = document.createElement("TR");
				
			}
			
			var newTdName = document.createElement("TD"),
				newTdVal = document.createElement("TD");
				
			newTdName.innerText = item;
			newTdName.width = "25%";
			
			var ownBuild = __data["nationBuildings"][item] || "0",
				reqBuild = buildings[item],
				clr = (parseInt(ownBuild, 10) < parseInt(reqBuild, 10))? "red" : "green",
				warn = (clr == "red")? SYMB_WARN : "";
			
			newTdVal.innerHTML = "<span class = '"+ clr+"'>" + ownBuild + "/ <b>"  + reqBuild + " </b>" + warn+"</span>" ;
			newTdVal.width = "25%";
			
			newTr.appendChild(newTdName);
			newTr.appendChild(newTdVal);
			n++;
			
			
		}
	}
	if(n == 1){
		
		//there is a remaining row with only one item in it, so
		//add an empty item after it 
		var newTdName = document.createElement("TD"),
				newTdVal = document.createElement("TD");
				
			newTdName.innerText = "";
			newTdName.width = "25%";
			
			newTdVal.innerText = "";
			newTdVal.width = "25%";
			
			newTr.appendChild(newTdName);
			newTr.appendChild(newTdVal);
			
			
		//then append it 
		insertAfter(newTr, prevNode);
	}
	
	
	//tr_requiredTechnologies
	var tr_requiredTechnologies = document.getElementById("tr_requiredTechnologies");
	//tr_requiredTechnologies.innerHTML = "";
	var tech = techInfo.requiredTechnologies;
	var prevNode = tr_requiredTechnologies;
	for (var i =0; i<tech.length; i++) {
		
		var item = tech[i];
		
		var newTr = document.createElement("TR");
			
		
		var newTdName = document.createElement("TD"),
			newTdVal = document.createElement("TD");
			
		
		var ownTech = typeof (__data["myTechnologies"][item["name"]]) != "undefined";
			clr = (ownTech)? "green" : "red",
			warn = (clr == "red")? SYMB_WARN : "";
			
			
			
		newTdName.innerHTML = "<span class = '"+ clr+"'>" + item["name"] + warn+"</span>" ;
		newTdName.colSpan = "2";
		
		
		newTdVal.innerHTML = "<span class = '"+ clr+"'>" + item["desc"] +"</span>" ;
		newTdVal.colSpan = "2";
		
		newTr.appendChild(newTdName);
		newTr.appendChild(newTdVal);
		
		insertAfter(newTr,prevNode);
		prevNode = newTr;
			
			
	}
	
	
}

/*REQUIRED TECHNOLOGIES



<tr>
										
											<td colspan = "2">
											
												Technology1
											</td>
											
										
										
											<td colspan = "2">
											
												Description here 
											</td>
											
										
										</tr>
										<tr>
										
											<td colspan = "2">
											
												Technology2
											</td>
											
										
										
											<td colspan = "2">
											
												Description here 
											</td>
											
										
										</tr>
										
										
			*/