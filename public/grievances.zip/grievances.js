function setAction(action, formId){
	
	document.getElementById("inAction"+ formId).className = action;
	
}