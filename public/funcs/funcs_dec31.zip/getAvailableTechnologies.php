<?php 

echo '

[
	{
		"id": "techId_1",
		"name": "Technology1"
	},
	{
		"id": "techId_2",
		"name": "Wawa 2"
	},
	{
		"id": "techId_3",
		"name": "Koko 3"
	}

]

';

?>
