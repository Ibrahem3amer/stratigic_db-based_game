<?php 

echo '
	{
		
		"Church": "3",
		"School": "15",
		"House": "100"
		
	}
';

?>