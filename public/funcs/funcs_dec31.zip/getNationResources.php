<?php

echo '
				 
{
	
	"money": "5000",
	"wood": "30",
	"Rock": "12",
	"Plastic": "5"
	
}
	
';
				
?>