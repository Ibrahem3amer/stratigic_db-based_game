<?php
echo '
[
	{
		"id": "tech_farming",
		"name": "Farming",
		"desc": "Tech Description 1"
	},
	{
		"id": "tech_crafting",
		"name": "Crafting",
		"desc": "Tech Description 2"
	},
	{
		"id": "tech_mining",
		"name": "Mining",
		"desc": "Tech Description 3"
	},
	{
		"id": "tech_Fishing",
		"name": "Fishing",
		"desc": "Tech Description 4"
	}
		
	
]
';
				
				
?>